#ifndef __SERIAL_H
#define __SERIAL_H

void recieveData(void);

#endif
